﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1._4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please provide input number:");
            int input = int.Parse(Console.ReadLine());
            int result = 0;
            int temp = input;
            while(temp!=0)
            {
                int remainder = temp % 10;
                result += remainder * remainder * remainder;
                temp = temp / 10;
            }
            if (input == result)
            {
                Console.WriteLine("{0} is armstrong number",input);
            }
            else
            {
                Console.WriteLine("{0} is not armstrong number",input);
            }
        }
    }
}
