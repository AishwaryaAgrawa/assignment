﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1._6
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, fact;
            Console.WriteLine("Enter the size of array :");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] num = new int[n];
            Console.WriteLine("Prime Numbers :");

            for(i=0; i< num.Length; i++)
            {
                fact = 0;
                for(j=1; j<=n; j++)
                {
                    if (i % j == 0)
                        fact++;
                }
                if (fact == 2)
                    Console.WriteLine("{0}", i);

            }
            Console.ReadLine();

        }
    }
}
