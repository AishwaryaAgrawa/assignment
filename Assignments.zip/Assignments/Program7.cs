﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1._7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please provide number of rows:");
            int noOfRows = int.Parse(Console.ReadLine());
            for(int row=noOfRows; row>=1;row--)
            {
                for(int column=1; column<=row; column++)
                {
                    Console.Write(column + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
