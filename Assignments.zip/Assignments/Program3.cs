﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1._3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] givenArray = { 9, 14, 4, 1, 0, 20, 30 };
            int largestElement = 0;

            for (int i=0; i<givenArray.Length;i++)
            {
                if(givenArray[i] > largestElement)
                {
                    largestElement = givenArray[i];
                }
            }
            Console.WriteLine("The largest element is : \n" + largestElement.ToString());


        }
    }
}
   
